"""Second exact arithmetic implementation: directed integer rounding.
No optimizer; verifies every stored algebraic certificate.
"""
if not __debug__:
    raise RuntimeError('Run exact verification without Python -O.')

import json,time,hashlib
from pathlib import Path
from kernel import check_integer_certificate
ROOT=Path(__file__).resolve().parent
start=time.time();data=json.loads((ROOT/'certificates.json').read_text());count=0;minimum=None
for r in data['cases']:
 c=r['certificate']
 if c['kind']=='separator':continue
 c=dict(c);c['Q']=10**12
 up,den=check_integer_certificate(r['n'],r['alpha'],r['k'],c)
 assert up<0 if c['kind']=='positive' else up<=0,(r['n'],r['alpha'],r['k'],up)
 count+=1
out={'all_exact_checks_passed':True,'algebra_cases':count,
     'arithmetic':'outward-rounded integer intervals','uses_optimizer':False,
     'seconds':round(time.time()-start,3),
     'certificate_sha256':hashlib.sha256((ROOT/'certificates.json').read_bytes()).hexdigest()}
(ROOT/'grid_audit_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
