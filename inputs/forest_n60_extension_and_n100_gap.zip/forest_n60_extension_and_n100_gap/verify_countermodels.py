#!/usr/bin/env python3
"""Exact witnesses against specified real-valued relaxations, NOT against forests.

Rebuilds the complete row domain independently of the discovery program. No
optimizer, SymPy, graph catalogue, or floating-point feasibility test is used.
"""
if not __debug__:
    raise RuntimeError('Do not run verification with Python -O.')

from pathlib import Path
from collections import Counter
from fractions import Fraction
import hashlib
import json
import time
from verify import choose, inc, row

ROOT = Path(__file__).resolve().parent

def expected_labels(n, a, extended):
    v = n-a
    labels = [('count', j) for j in range(2, v+1)]
    labels += [('path', r) for r in range(2, a+1)]
    labels += [('private', j, h) for j in range(2, v+1) for h in range(a)]
    labels += [('hall', r, l) for l in range(1, a+1)
               for r in range(min(v, a-l))
               if v-r-max(0, l-(a-v)) >= 0]
    if extended:
        labels += [(tag, r) for tag in
                   ('cover', 'edge_lower', 'edge_upper', 'mean', 'union')
                   for r in range(2, v+1)]
        labels += [('tail', r, h) for r in range(2, v+1)
                   for h in range(a-r+2)]
        labels += [('hall', r, 0) for r in range(1, v)]
        labels += [(tag, r, h) for tag in ('release_upper', 'tail_upper')
                   for r in range(2, v+1)
                   if v-r+1 > max(0, a-v-1)
                   for h in range(a-r+2)]
    assert len(labels) == len(set(labels))
    return labels

def check(path, expected):
    obj = json.loads(path.read_text())
    n, a, k, extended = expected
    assert (obj['n'], obj['alpha'], obj['k']) == (n, a, k)
    assert obj['model'] == ('extended' if extended else 'original')
    v = n-a
    denominator = int(obj['denominator'])
    assert denominator > 0
    values = {}
    for j, m, numerator in obj['counts']:
        assert type(j) is int and type(m) is int
        assert 1 <= j <= v and 0 <= m <= a-j
        assert (j, m) not in values
        numerator = int(numerator)
        assert numerator > 0
        values[j, m] = numerator
    keys = [(j, m) for j in range(1, v+1) for m in range(a-j+1)]
    nums = [values.get(key, 0) for key in keys]
    assert sum(z for z, (j, m) in zip(nums, keys) if j == 1) == v*denominator
    labels = expected_labels(n, a, extended)
    stored = [tuple(label) for label in obj['row_labels']]
    assert len(stored) == len(set(stored))
    assert set(stored) == set(labels), 'Incomplete or enlarged row domain'
    saturated = 0
    for label in labels:
        if label[0] == 'cover':
            r = label[1]
            lhs = -sum(z for z, (j, m) in zip(nums, keys) if j == r)
            bound = -max(0, choose(v, r)-max(0, a-v-1)*choose(v-2, r-2))
        else:
            coeff, bound, _ = row(n, a, label, keys)
            lhs = sum(c*z for c, z in zip(coeff, nums) if c and z)
        assert lhs <= bound*denominator, (label, lhs-bound*denominator)
        saturated += lhs == bound*denominator
    def delta(r):
        return inc(a, 0, r)*denominator + sum(
            z*inc(m, j, r) for z, (j, m) in zip(nums, keys) if z)
    dk, dn = delta(k), delta(k+1)
    assert dk == int(obj['delta_k_numerator'])
    assert dn == int(obj['delta_next_numerator'])
    assert dk < 0 < dn
    # Simple display bounds are themselves checked by integer comparisons.
    if n == 100:
        assert dk < -2*10**18*denominator
        assert dn > 3*10**17*denominator
        display = {'delta_k_strict_upper': -2*10**18,
                   'delta_next_strict_lower': 3*10**17}
    else:
        assert dk < -69000000*denominator
        assert dn > 74000*denominator
        display = {'delta_k_strict_upper': -69000000,
                   'delta_next_strict_lower': 74000}
    # They really define c_0=1, c_1=n, and degree alpha, but only formal coefficients.
    c1 = a*denominator + sum(z*choose(m, 1-j) for z,(j,m) in zip(nums,keys))
    assert c1 == n*denominator
    ca = denominator + sum(z*choose(m, a-j) for z,(j,m) in zip(nums,keys))
    assert ca >= denominator
    return {'n': n, 'alpha': a, 'k': k, 'model': obj['model'],
            'all_exact_checks_passed': True,
            'nonzero_count_variables': len(values), 'rows_checked': len(labels),
            'row_type_counts': dict(Counter(label[0] for label in labels)),
            'saturated_rows': saturated,
            'denominator_digits': len(str(denominator)),
            'strict_valley': True, **display,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def main():
    start = time.time()
    results = [check(ROOT/'countermodel_55_30_18.json', (55,30,18,False)),
               check(ROOT/'countermodel_100_55_31.json', (100,55,31,True))]
    summary = {'all_exact_checks_passed': True,
               'scope': 'Countermodels ONLY to the explicitly enumerated real-valued structural relaxations. Neither is a forest counterexample.',
               'uses_optimizer': False, 'uses_floating_point_feasibility': False,
               'results': results, 'seconds': round(time.time()-start,3)}
    (ROOT/'countermodel_audit_results.json').write_text(
        json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
