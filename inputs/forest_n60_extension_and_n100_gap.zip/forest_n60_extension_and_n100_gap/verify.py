#!/usr/bin/env python3
"""Independent exact verifier. Python standard library only; no graph enumeration.
Reconstructs the inequalities independently of kernel.py and uses common-
denominator integer arithmetic, not the discovery program's interval rounding.
"""
if not __debug__:
    raise RuntimeError('Run exact verification without Python -O.')

import json, math, time, hashlib
from pathlib import Path
from fractions import Fraction
from collections import Counter
from functools import lru_cache
ROOT=Path(__file__).resolve().parent

@lru_cache(None)
def choose(n,k):return math.comb(n,k) if 0<=k<=n else 0

@lru_cache(None)
def inc(m,j,k):return choose(m,k-j)-choose(m,k-j-1)

def qcoeff(a,v,k):return sum(choose(v,j)*2**j*choose(a-v,k-j)for j in range(min(v,k)+1))

def automatic(n,a,k):
    v=n-a
    if choose(n-k+1,k)>qcoeff(a,v,k-1):return 'path_matching'
    if qcoeff(a,v,k+1)<=choose(n-k+1,k):return 'matching_path'
    lower=inc(a,0,k)
    for j in range(1,min(v,k)+1):
        vals=[inc(m,j,k)for m in range(a-j+1)]
        if j>1:vals.append(0)
        lower+=choose(v,j)*min(vals)
    if lower>0:return 'lower'
    upper=inc(a,0,k+1)
    for j in range(1,min(v,k+1)+1):
        vals=[inc(m,j,k+1)for m in range(a-j+1)]
        if j>1:vals.append(0)
        upper+=choose(v,j)*max(vals)
    if upper<=0:return 'upper'
    return None

def separator(a,v,k,t):
    assert t>=0
    answer=Fraction(inc(a,0,k+1))-t*inc(a,0,k)
    for j in range(1,min(v,k+1)+1):
        vals=[Fraction(inc(m,j,k+1))-t*inc(m,j,k)for m in range(a-j+1)]
        if j>1:vals.append(Fraction(0))
        answer+=choose(v,j)*max(vals)
    return answer

def row(n,a,name,keys):
    """Unweighted coefficients of the counts t_(j,m), and weighted row norm."""
    v=n-a;tag=name[0]
    if tag=='count':
        j0=name[1];assert 2<=j0<=v
        coefficients=[int(j==j0)for j,m in keys];rhs=choose(v,j0)
    elif tag=='path':
        r=name[1];assert 2<=r<=a
        coefficients=[-choose(m,r-j)for j,m in keys]
        rhs=choose(a,r)-choose(n-r+1,r)
    elif tag=='private':
        j0,h=name[1:];assert 2<=j0<=v and 0<=h<a
        coefficients=[]
        for j,m in keys:
            if j==j0:z=max(0,j0*(m-h)+a-m-j0+1)
            elif j==j0-1:z=-(v-j0+1)*max(m-h,0)
            else:z=0
            coefficients.append(z)
        rhs=0
    elif tag=='hall':
        r,l=name[1:];assert 0<=l<=a and 0<=r<min(v,a-l)
        h=v-r-max(0,l-a+v);assert h>=0
        coefficients=[choose(m,l)*((r+1)*(j==r+1)-h*(j==r))for j,m in keys]
        rhs=h*choose(a,l) if r==0 else 0
    elif tag=='tail':
        r,h=name[1:];assert 2<=r<=v and 0<=h<=a-r+1
        coefficients=[]
        for j,m in keys:
            if j==r:z=r if m>=h else int(a+(r-1)*m>=r*h)
            elif j==r-1:z=-(v-r+1)*int(m>=h)
            else:z=0
            coefficients.append(z)
        rhs=0
    elif tag=='mean':
        r=name[1];assert 2<=r<=v
        beta=choose(v-2,r-1)-(a-2)*choose(v-2,r-2)
        base=a*choose(v-2,r)+(2*a-n+1)*choose(v-2,r-1)
        coefficients=[-m*(j==r)-beta*(j==2)for j,m in keys]
        rhs=-base-beta*choose(v,2)
    elif tag=='union':
        r=name[1];assert 2<=r<=v
        w=choose(v-1,r-1)
        coefficients=[(a-m)*((j==r)-w*(j==1))for j,m in keys];rhs=0
    elif tag in ('release_upper','tail_upper'):
        r,h=name[1:];assert 2<=r<=v and 0<=h<=a-r+1
        extent=max(0,v-r+1-max(0,a-v-1));coefficients=[]
        for j,m in keys:
            if j==r-1:
                z=extent*(max(0,m-h)if tag=='release_upper'else int(m>=h))
            elif j==r:
                total=a-m;cap=total-r+1;t=h-m
                if tag=='tail_upper':
                    upper=r if t<=0 else (min(r,total//t)if t<=cap else 0)
                elif t<=0:upper=total-r*t
                elif t>=cap:upper=0
                else:
                    q,rem=divmod(total,cap);upper=q*(cap-t)+max(0,rem-t)
                z=-upper
            else:z=0
            coefficients.append(z)
        rhs=0
    elif tag=='edge_lower':
        r=name[1];assert 2<=r<=v;w=choose(v-2,r-2)
        coefficients=[-(j==r)+w*(j==2)for j,m in keys]
        rhs=-choose(v,r)+w*choose(v,2)
    elif tag=='edge_upper':
        r=name[1];assert 2<=r<=v
        budget=min(max(0,a-v-1),v-1)
        if budget==0:
            coefficients=[int(j==r)for j,m in keys];rhs=choose(v,r)
        else:
            gap=choose(v-1,r-1)-choose(v-budget-1,r-1)
            coefficients=[budget*(j==r)-gap*(j==2)for j,m in keys]
            rhs=budget*choose(v,r)-gap*choose(v,2)
    elif tag=='assumption':
        r=name[1];coefficients=[inc(m,j,r)for j,m in keys];rhs=-inc(a,0,r)
    else:raise AssertionError(tag)
    scale=max([1,abs(rhs)]+[abs(z)*choose(v,j)for z,(j,m)in zip(coefficients,keys)])
    return coefficients,rhs,scale

def algebra(n,a,k,certificate):
    v=n-a;keys=[(j,m)for j in range(1,v+1)for m in range(a-j+1)]
    typ=certificate['kind'];assert typ in ('positive','negative','conditional')
    D=certificate['D'];H=certificate['eta'];assert type(D)is int and D>0 and type(H)is int
    sgn=-1 if typ=='positive' else 1;r=k if typ=='positive' else k+1
    c=[sgn*inc(m,j,r)for j,m in keys];constant=sgn*inc(a,0,r)
    scale=max([1,abs(constant)]+[abs(z)*choose(v,j)for z,(j,m)in zip(c,keys)])
    stored=[];norms=[v,scale]
    for item in certificate['rows']:
        label=item['name'];mult=item['mult'];assert type(mult)is int and mult>=0
        if label[0]=='assumption':assert typ=='conditional' and label==['assumption',k]
        ar,b,norm=row(n,a,label,keys);stored.append((mult,ar,b,norm));norms.append(norm)
    L=math.lcm(*norms)
    residual=[D*(L//scale)*z-H*(L//v)*(j==1)for z,(j,m)in zip(c,keys)]
    result=D*(L//scale)*constant+H*L
    for mult,ar,b,norm in stored:
        factor=mult*(L//norm);result+=factor*b
        for i,z in enumerate(ar):
            if z:residual[i]-=factor*z
    maxima=[0]*(v+1)
    for z,(j,m)in zip(residual,keys):maxima[j]=max(maxima[j],z)
    result+=sum(choose(v,j)*maxima[j]for j in range(1,v+1))
    assert result<0 if typ=='positive' else result<=0,(n,a,k,typ,result)
    return Fraction(result,D*L),len(stored),len(str(L))

def main():
    start=time.time();path=ROOT/'certificates.json';data=json.loads(path.read_text())
    assert data['maximum_order']==60
    entries={}
    for rec in data['cases']:
        key=(rec['n'],rec['alpha'],rec['k']);assert key not in entries;entries[key]=rec['certificate']
    used=set();counts=Counter();per_n={};min_margin=None;worst=None;total_terms=0;max_lcm_digits=0
    for n in range(2,61):
        number=0
        for a in range((n+1)//2,n):
            for k in range(1,(2*a+1)//3):
                number+=1;key=(n,a,k);tag=automatic(n,a,k)
                if tag is not None:
                    assert key not in entries,('redundant entry',key)
                    counts[tag]+=1;continue
                assert key in entries,('missing case',key)
                cert=entries[key];used.add(key);tag=cert['kind']
                if tag=='separator':
                    val=separator(a,n-a,k,Fraction(cert['t']));assert val<=0,(key,val)
                else:
                    val,terms,digits=algebra(n,a,k,cert);total_terms+=terms;max_lcm_digits=max(max_lcm_digits,digits)
                    margin=-val
                    if min_margin is None or margin<min_margin:min_margin=margin;worst=key
                counts[tag]+=1
        per_n[n]=number
    assert used==set(entries),('unused entries',set(entries)-used)
    answer={
        'all_exact_checks_passed':True,'maximum_order':60,
        'scope':'all forests, all maximum degrees and component counts; unimodality, not full log-concavity',
        'scalar_parameter_cases':sum(per_n.values()),'case_counts':dict(counts),
        'stored_cases':len(entries),'algebra_cases':sum(counts[t]for t in ('positive','negative','conditional')),
        'algebra_weight_terms':total_terms,'largest_common_denominator_digits':max_lcm_digits,
        'minimum_normalized_algebra_margin':str(min_margin),'worst_case_n_alpha_k':worst,
        'per_order_parameter_cases':per_n,
        'certificate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'seconds':round(time.time()-start,3),
        'uses_optimizer':False,'uses_graph_catalogue':False,
    }
    (ROOT/'audit_results.json').write_text(json.dumps(answer,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(answer,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
