"""Exact, graph-free algebra for a bounded-size forest-unimodality certificate.
No tree catalogue, graph generator, or optimizer is imported here.
"""
if not __debug__:
    raise RuntimeError('Run exact verification without Python -O.')

from math import comb
from fractions import Fraction
from functools import lru_cache

@lru_cache(None)
def C(n,k):
    return comb(n,k) if 0 <= k <= n else 0

def difference(m,j,k):
    return C(m,k-j)-C(m,k-j-1)

def key_list(a,v):
    return [(j,m) for j in range(1,v+1) for m in range(a-j+1)]

def row_names(n,a):
    v=n-a
    names=[('count',j) for j in range(2,v+1)]
    names += [('path',r) for r in range(2,a+1)]
    names += [('private',j,h) for j in range(2,v+1) for h in range(a)]
    names += [('hall',j,l) for l in range(1,a+1)
              for j in range(min(v,a-l)) if v-j-max(0,l-(a-v))>=0]
    names += [('hall',j,0)for j in range(1,v)]
    names += [(tag,j)for tag in ('mean','union','edge_lower','edge_upper')for j in range(2,v+1)]
    names += [(tag,j,h)for tag in ('tail','release_upper','tail_upper')for j in range(2,v+1)for h in range(a-j+2)]
    return names

def make_row(n,a,name,keys=None):
    v=n-a;keys=key_list(a,v) if keys is None else keys
    ty=name[0];rhs=0
    if ty=='count':
        r=name[1];rhs=C(v,r)
        f=lambda j,m:int(j==r)
    elif ty=='path':
        r=name[1];rhs=C(a,r)-C(n-r+1,r)
        f=lambda j,m:-C(m,r-j)
    elif ty=='private':
        r,h=name[1:]
        def f(j,m):
            if j==r:return max(0,(r-1)*m+a-r+1-r*h)
            if j==r-1:return -(v-r+1)*max(0,m-h)
            return 0
    elif ty=='hall':
        r,l=name[1:];c=v-r-max(0,l-(a-v))
        rhs=c*C(a,l) if r==0 else 0
        f=lambda j,m:((r+1)*int(j==r+1)-c*int(j==r))*C(m,l)
    elif ty=='tail':
        r,h=name[1:]
        def f(j,m):
            if j==r:return r if m>=h else int(r*h<=a+(r-1)*m)
            if j==r-1:return -(v-r+1)*int(m>=h)
            return 0
    elif ty=='mean':
        r=name[1];beta=C(v-2,r-1)-(a-2)*C(v-2,r-2)
        rhs=-a*C(v-2,r)-(2*a-n+1)*C(v-2,r-1)-beta*C(v,2)
        f=lambda j,m:-m*int(j==r)-beta*int(j==2)
    elif ty=='union':
        r=name[1];w=C(v-1,r-1);f=lambda j,m:(a-m)*(int(j==r)-w*int(j==1))
    elif ty in ('release_upper','tail_upper'):
        r,h=name[1:];extent=max(0,v-r+1-max(0,a-v-1))
        def f(j,m):
            if j==r-1:return extent*(max(0,m-h)if ty=='release_upper'else int(m>=h))
            if j!=r:return 0
            total=a-m;cap=total-r+1;q,rem=divmod(total,cap)
            if ty=='tail_upper':return -(r if m>=h else (min(r,total//(h-m))if h<=m+cap else 0))
            bound=q*max(0,m+cap-h)
            if q<r:bound+=max(0,m+rem-h)+(r-q-1)*max(0,m-h)
            return -bound
    elif ty=='edge_lower':
        r=name[1];w=C(v-2,r-2);rhs=-C(v,r)+w*C(v,2)
        f=lambda j,m:-int(j==r)+w*int(j==2)
    elif ty=='edge_upper':
        r=name[1];budget=min(max(0,a-v-1),v-1)
        if budget==0:
            rhs=C(v,r);f=lambda j,m:int(j==r)
        else:
            gap=C(v-1,r-1)-C(v-budget-1,r-1)
            rhs=budget*C(v,r)-gap*C(v,2)
            f=lambda j,m:budget*int(j==r)-gap*int(j==2)
    elif ty=='assumption':
        r=name[1];rhs=-difference(a,0,r)
        f=lambda j,m:difference(m,j,r)
    else:raise ValueError(name)
    raw=[C(v,j)*f(j,m) for j,m in keys]
    norm=max([1,abs(rhs)]+[abs(x)for x in raw])
    return raw,rhs,norm

def objective(n,a,k,kind,keys=None):
    keys=key_list(a,n-a) if keys is None else keys
    sign=-1 if kind=='positive' else 1
    index=k if kind=='positive' else k+1
    raw=[sign*C(n-a,j)*difference(m,j,index) for j,m in keys]
    const=sign*difference(a,0,index)
    norm=max([1,abs(const)]+[abs(x)for x in raw])
    return raw,const,norm

def ceildiv(a,b): return -((-a)//b)

def check_integer_certificate(n,a,k,cert):
    """Return a rigorous upper bound numerator / (D*Q).
    Positive kind certifies -Delta_k<0. Other kinds certify Delta_(k+1)<=0,
    with Delta_k<=0 additionally assumed only for kind='conditional'.
    """
    v=n-a;keys=key_list(a,v);D=int(cert['D']);Q=int(cert['Q'])
    assert D>0 and Q>0
    kind=cert['kind'];assert kind in ('positive','negative','conditional')
    obj,const,norm=objective(n,a,k,kind,keys)
    eta=int(cert['eta'])
    residual=[D*ceildiv(Q*z,norm)-eta*Q*int(j==1)
              for z,(j,m) in zip(obj,keys)]
    upper=D*ceildiv(Q*const,norm)+eta*Q
    allowed=set(row_names(n,a))
    if kind=='conditional':allowed.add(('assumption',k))
    for item in cert['rows']:
        name=tuple(item['name']);mult=int(item['mult'])
        assert name in allowed and mult>=0
        raw,rhs,scale=make_row(n,a,name,keys)
        upper += mult*ceildiv(Q*rhs,scale)
        for i,z in enumerate(raw):
            if z:residual[i]-=mult*((Q*z)//scale)
    # Sum_m x_(j,m) <= 1; a positive residual needs at most its layer maximum.
    maxima=[0]*(v+1)
    for r,(j,m) in zip(residual,keys):
        if r>maxima[j]:maxima[j]=r
    upper+=sum(maxima)
    return upper,D*Q

def elementary_bound(a,v,k,kind,t=Fraction(0)):
    if kind=='lower':
        z=difference(a,0,k)
        for j in range(1,min(v,k)+1):
            vals=[difference(m,j,k)for m in range(a-j+1)]
            if j>1:vals.append(0)
            z+=C(v,j)*min(vals)
        return z
    if kind=='upper':
        z=difference(a,0,k+1)
        for j in range(1,min(v,k+1)+1):
            vals=[difference(m,j,k+1)for m in range(a-j+1)]
            if j>1:vals.append(0)
            z+=C(v,j)*max(vals)
        return z
    if kind=='separator':
        assert t>=0
        z=difference(a,0,k+1)-t*difference(a,0,k)
        for j in range(1,min(v,k+1)+1):
            vals=[difference(m,j,k+1)-t*difference(m,j,k)for m in range(a-j+1)]
            if j>1:vals.append(Fraction(0))
            z+=C(v,j)*max(vals)
        return z
    raise ValueError(kind)
